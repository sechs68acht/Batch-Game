Hauptmen�/Men�:
	W/S : Bewegen der Markierung
	D : Auswahl best�tigen
Map:
	S : Men�

Nachrichten:
	Beliebige Taste : Weiter

Items:
	A/D : Ansehen der Items
	X : Abbrechen